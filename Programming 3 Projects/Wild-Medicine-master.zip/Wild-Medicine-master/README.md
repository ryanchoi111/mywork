# Wild-Medicine
Senior project for Milton Academy
Ethan Berman
Sources Consulted

Nols WMI Resources: https://www.nols.edu/en/resources/wilderness-medicine-resources/
Used this source for case study information for training data 
Human body outline:
https://images.template.net/wp-content/uploads/2015/08/Printable-Human-Body-Outline.jpg
https://forums.developer.apple.com/thread/62404
Used this for reading in csv files
https://www.hackingwithswift.com/example-code/uikit/how-to-send-an-email
-used this for code for sending emails through code


