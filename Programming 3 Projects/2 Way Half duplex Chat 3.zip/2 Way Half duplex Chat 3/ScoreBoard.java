import java.applet.*;
import java.awt.*;
import java.awt.event.*;


public class ScoreBoard
	{
		public String name; 
		public int xpos;
		public int ypos;
		public int height;
		public int width;
      public int score;
   }
