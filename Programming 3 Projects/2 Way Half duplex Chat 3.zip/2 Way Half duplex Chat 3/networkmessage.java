public class networkmessage  implements java.io.Serializable
{
	public int serialnum;
	public String ipnum;
	public boolean up, down;
   public int xpos, ypos;

	public networkmessage(boolean u, boolean d )
	{
		up = u;
      down = d;

	}
   
  	public networkmessage(int x, int y)
	{ 
      xpos = x;
      ypos = y;
   }
   
}