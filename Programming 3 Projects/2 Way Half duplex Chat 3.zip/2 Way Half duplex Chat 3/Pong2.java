import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;

import javax.swing.JFrame;
import javax.swing.JPanel;
import java.awt.*;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.Clip;
import java.io.File;
import javax.sound.*;
import java.io.InputStream;


import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;


import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.Clip;
import java.io.File;
import javax.sound.*;
import java.io.InputStream;








public class Pong2 implements  KeyListener
{
   final int WIDTH = 1280;
   final int HEIGHT = 720;

 
   public ScoreBoard myscore1,myscore2;
   public Image offscreen;	//double buffering variables
   public Graphics bufferGraphics;	//double buffering variables
   //public AudioInputStream ais;
   //public AudioClip clip;

   JFrame frame;
   Canvas canvas;
   File f;
   BufferStrategy bufferStrategy;
   

   Player player1, player2;
   Ping ball;
   Image RectanglePic,ballPic,Grey,linePic;

   

   public ObjectOutputStream oos;
   public ObjectInputStream ois;
   public Socket connection;
   public ServerSocket server;
   public String ip, clientIP, textin, exitword ="exit";
   public networkmessage nmessage;
   public boolean connected=false;
   public boolean done=false;
   public String myName="",mode="";
   public int counter = 0;
   public int sleepTime = 3;
   public BufferedReader inn;
   
   sendThread st;
   receiveThread rt;
   mainThread mt;
   BufferedReader brin = new BufferedReader(new InputStreamReader(System.in));





   public static void main(String[] args) {
      System.out.println("R");
      Pong2 ex = new Pong2();
   }





   public Pong2()
   {
   
      frame = new JFrame("Basic Game");
   
   
   
      JPanel panel = (JPanel) frame.getContentPane();
      panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
      panel.setLayout(null);
      canvas = new Canvas();
      canvas.setBounds(0, 0, WIDTH, HEIGHT);
      canvas.setIgnoreRepaint(true);
   
      panel.add(canvas);
   
      canvas.addKeyListener(this);
   
      frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
      frame.pack();
      frame.setResizable(false);
      frame.setVisible(true);
      
      
      
      myscore1 = new ScoreBoard();
      myscore2 = new ScoreBoard();
   
      
      player1=new Player();
      player2=new Player();
      player2.xpos=1200;
      ball=new Ping();
   
      myscore1.score=ball.myscore1;
      myscore2.score=ball.myscore2;
   
      RectanglePic =  Toolkit.getDefaultToolkit().getImage("Rectangle.png");
      ballPic =  Toolkit.getDefaultToolkit().getImage("Bouncy_ball.png");
      Grey =  Toolkit.getDefaultToolkit().getImage("grey-09.jpg");
   
   
   
   
      canvas.createBufferStrategy(2);
      bufferStrategy = canvas.getBufferStrategy();
      canvas.requestFocus();
           
        
   
      try
      {
         BufferedReader brin = new BufferedReader(new InputStreamReader(System.in));
         System.out.print("Enter your name:>"); //send prompt to DOS window
         mode =brin.readLine();		//read in user input
         //myName=""+player1.xpos+" "+player1.ypos;		//read in user input
      
      
      }
      
      catch (Exception inread)
      {
      }
      runServer();
   
   
   
      canvas.requestFocus();
   
   
   }//init()
   
   

   public void runServer()
   {
      inn = new BufferedReader(new InputStreamReader(System.in));
      mt=new mainThread();
      st = new sendThread();
      rt = new receiveThread();
   
   	//All networking stuff has to be put into try - catches
      try //catch(SocketException sx)
      {
         setupNetworking();
         mt.start();
         st.start();
         rt.start();
            
      }//try
      
      catch(Exception ex2)		// if the above fails close up things and then try again
      {
      
      }//SocketException sx
   
   
   } //runServer
   class mainThread extends Thread//threads sending to make it less laggy
   {
   
   //thread
      public void run() {
      
         while (true) {
         // paint the graphics
            render();
            ball.move();
            
      
         checkIntersections();
      
         frame.getContentPane().repaint();
      

         
         
         // move things
          
            if (player1.up)
               player1.ypos-=2;
            if (player1.down)
               player2.ypos+=2;
         
            if (player2.up)
               player2.ypos-=2;
            if (player2.down)
               player2.ypos+=2;
         
         
         
         
         //sleep
            try {
               Thread.sleep(1);
            }
            catch (InterruptedException e) {
            
            }
         }
      }
   }

   
   public void render()
   {
   
      Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
      g.clearRect(0, 0, WIDTH, HEIGHT);
   
      g.setColor(Color.WHITE);								//change the "working" color to blue   
      g.drawImage(Grey,0,0,1280,720,null);     
      g.drawImage(linePic,640,0,3,720,null);
      
      g.drawString("MYSCORE: "+myscore1.score,50,50);
      g.drawString("MYSCORE: "+myscore2.score,1100,50);
      g.drawImage(RectanglePic,player1.xpos,player1.ypos,player1.width,player1.height,null);
      g.drawImage(RectanglePic,player2.xpos,player2.ypos,player2.width,player2.height,null);   
      g.drawImage(ballPic,ball.x,ball.y,ball.size,ball.size,null);
      g.drawImage(offscreen,0,0,null);
   
   
   
      g.dispose();
   
      bufferStrategy.show();
   
   }

   public void keyPressed(KeyEvent e) {
      char key = e.getKeyChar();
      System.out.println("Key Pressed: " + key);
   
      switch (key) {
         case 'o':
            player1.up = true;
            break;
      
         case 'l':
            player1.down = true;
            break;
      
      
      }
   
   }


   // This runs whenever a key is released
   public void keyReleased(KeyEvent e) {
      char key = e.getKeyChar();
      System.out.println("Key Pressed: " + key);
   
      switch (key) {
         case 'o':
            player2.up = false;
            break;
      
         case 'l':
            player2.down = false;
            break;
      
      }
   }

   public void keyTyped( KeyEvent event )
   {
        //keyTyped() only runs if a printable key is pressed. It does not respond to arrow keys, space, tab, etc.
      char keyin;
      keyin = event.getKeyChar(); //getKeyChar() returns the character of the printable key pressed.
        // System.out.println ("Key Typed: "+ keyin);
   }//keyTyped()
    
   class sendThread extends Thread//threads sending to make it less laggy
   {
      public void run()
      {
         int counter=0;
      
         while (connected)
         {
            try
            {
            	//System.out.println("fjwehjewhehwehejehjwe");
               textin = inn.readLine();		//read in user input
               //System.out.println("inn.readLine():    "+inn.readLine());//capable of reading in...
               //System.out.println("textIn:    "+textin);//textIn does not accept new value.
            
               if (textin!=null)
               {
                  if (textin.equals(exitword))  // if "exit" is typed in shutdown the server.
                     serverShutdown();
                  else
                     sendData();					//send data to server
               }
               
               
               try
               {
                  Thread.sleep(sleepTime);			// this sets the thread to sleep
               }
               catch (InterruptedException e)
               {
               }
            }//try
            
            catch (Exception e)
            {
               e.printStackTrace();
            }//catch
         
         
            try {
               Thread.sleep(1);
            }
            catch (InterruptedException e) {
            
            }
         
         
         }
      }//run
   }//sendThread
   
  class receiveThread extends Thread//threads sending to make it less laggy
   {
      public void run()
      {
         while (true)
         {
            try
            {
               //System.out.println("RECEIVE");
               networkmessage messageIn =(networkmessage)(ois.readObject());

               if(messageIn!=null)
               {
                  player1.up = messageIn.up;
                  player1.down = messageIn.down;
                  //System.out.println("got "+xpos+"  "+ypos);
               }

               try
               {
                  Thread.sleep(sleepTime);			// this sets the thread to sleep
               }
               catch (InterruptedException e)
               {
               }
            	//receiving
            }//try
            catch (Exception e)
            {
               e.printStackTrace();
            }//catch

            try {
               Thread.sleep(1);
            }
            catch (InterruptedException e) {

            }


         }
      }//run
   }//receiveThread   
   
	//setup connection
   public void setupConnection() throws IOException
   {
      System.out.println("CLIENT MODE ACTIVATED");
      {
         System.out.print("Enter the server IP Address>"); //send prompt to DOS window
         ip = brin.readLine();
      
         System.out.println("Connecting");
         connection = new Socket (ip, 7777);  						//create the socket at port 8000
         System.out.println("Connected to "+ip);
      
      }
   
   
   }//setupconnection()   
	//Setup streams connection
   public void setupStreams() throws IOException
   {
   	//Open up Streams
      System.out.println("Streams Setup");
      oos=new ObjectOutputStream(connection.getOutputStream()); //construct object output stream
      oos.flush();
      ois=new ObjectInputStream(connection.getInputStream());
   
   }//setupStreams()




   public void setupNetworking()
   {
      try
      {
         setupConnection();  //setup sockets, wait for a connection
         setupStreams();		//after connected, setup streams
         connected = true;
      }
      
      catch(Exception ex2)
      {
         System.out.println(ex2);
      } // catch(Exception ex2)
   
   }

   public void resetConnection()
   {
      try //catch(Exception ex2)
      {
         ois.close();
         server.close();
         connection.close();
         //runServer();
      } //try
      catch(Exception ex2)
      {
         System.out.println(ex2);
      } // catch(Exception ex2)
   
   
   
   }




   public void checkIntersections()
   {
      if(player1.rec.intersects(ball.rec))
      {
         ball.reverseDirection();
      
      
      }
   
      if(player2.rec.intersects(ball.rec))
      {
         ball.reverseDirection();
      }
      
      if(ball.x==0+ball.size)
      {
      
         ball.isAlive=false;
         myscore1.score++;
      }
      if(ball.x==1280-ball.size)
      {
      
         ball.isAlive=false;
         myscore2.score++;
      }
      if(ball.isAlive==false)
      {
         ball.x=WIDTH/2;
         ball.y=HEIGHT/2;
         ball.isAlive=true;
      }
      
      
   
   
   }

	
	//method to write/send network data
   public void sendData() throws IOException
   {
      try
      {
         nmessage = new networkmessage(player2.up, player2.down);
         oos.writeObject(nmessage);
         
         System.out.println("Sending  "+player2.xpos+"   "+player2.ypos);
      }//try
      
      catch (IOException ioException)
      {
         System.out.println("IO exception in sendData");
      }
   
   }//sendData()


	//method to read in network data
   public void getData() throws IOException
   {
      try
      {
         
         networkmessage messageIn = (networkmessage)(ois.readObject());
         System.out.println("getting");
         if(messageIn!=null)
         {
            player2.xpos = messageIn.xpos;
            player2.ypos = messageIn.ypos;
         }
      }//try
      
      catch (Exception exp1)
      {
         System.out.println("IO exception in getData");
      }
      
   
   }//getData()




/*  ****************************************************************
serverShutdown()
set done to true
closes streams
******************************************************************** */

   public void serverShutdown()
   {
      System.out.println("exiting initiated");
   
      try
      {
         done = true;
         textin = "Chat is terminated.  Have a nice day.";
         sendData();
         oos.close();
         server.close();
         connection.close();
      }
      
      catch (Exception One)
      {
         System.out.println("bad termination");
      }
   }





}











