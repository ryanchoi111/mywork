
// KJC @ Milton
// Two way full duplex chat server


import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;
import java.awt.*;//active window tokin for graphics
import java.awt.image.BufferStrategy;
import java.util.ArrayList;
import java.awt.Canvas;
import java.awt.Dimension;
import java.awt.Graphics2D;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

import javax.swing.JFrame;
import javax.swing.JPanel;




public class serverProgIIActual extends Frame implements Runnable, KeyListener
{
    final int WIDTH = 1000;
    final int HEIGHT = 700;

    public ScoreBoard myscore;
    public Image offscreen;	//double buffering variables
    public Graphics bufferGraphics;	//double buffering variables


    JFrame frame;
    Canvas canvas;
    BufferStrategy bufferStrategy;
    

   public ObjectOutputStream oos;
   public ObjectInputStream ois;
   public Socket connection;
   public ServerSocket server;
   public String ip, clientIP, textin, exitword ="exit";
   public networkmessage nmessage;
   public boolean connected=false;
   public boolean done=false;
   public String myName="";
   public int counter = 0;
   public int sleepTime = 3;
   public BufferedReader inn;
   sendThread st;
   receiveThread rt;



    Player player1, player2;
    Ping ball;
    Image RectanglePic;


/*  main method
	required method for all applications.
	It's the first method run when the program starts.
	This main method calls the serverProg constructor
*/

   public static void main(String[] args)
   {
      new serverProgIIActual();
     // new Thread(ex).start();


   }


   public  serverProgIIActual()
   {
   
        frame = new JFrame("Basic Game");

        JPanel panel = (JPanel) frame.getContentPane();
        panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        panel.setLayout(null);

        canvas = new Canvas();
        canvas.setBounds(0, 0, WIDTH, HEIGHT);
        canvas.setIgnoreRepaint(true);

        panel.add(canvas);

        canvas.addKeyListener(this);

        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setResizable(false);
        frame.setVisible(true);



        myscore = new ScoreBoard();

        player1=new Player();
        player2=new Player();
        ball=new Ping();

        myscore.score=0;
        RectanglePic =  Toolkit.getDefaultToolkit().getImage("Rectangle.png");



        canvas.createBufferStrategy(2);
        bufferStrategy = canvas.getBufferStrategy();
        canvas.requestFocus();



      try
      {
         BufferedReader brin = new BufferedReader(new InputStreamReader(System.in));
         System.out.print("Enter your name:>"); //send prompt to DOS window
         myName=""+player1.xpos+" "+player1.ypos;		//read in user input
      }

      catch (Exception inread)
      {
      }
      runServer();


   }


/*	runServer()
	This is where all the actual work gets done.
*/


   


    public void render()
    {
        Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
        g.clearRect(0, 0, WIDTH, HEIGHT);

        g.setColor(Color.BLUE);								//change the "working" color to blue
        g.drawString("Myscore: "+myscore.score,50,50);
        g.drawImage(RectanglePic,player1.xpos,player1.ypos,player1.width,player1.height,null);

        g.drawImage(offscreen,0,0,null);



        g.dispose();

        bufferStrategy.show();

    }


    public void run() {

        while (true) {
            //MOVE THINGS
            render();
            System.out.println("HA");
         /*for (int h = 0; h < mushrooms.size(); h++) {
            tempSprite1 = mushrooms.get(h);
            tempSprite1.move(mario.xpos, mario.ypos);

         }*/

            checkIntersections();

            frame.getContentPane().repaint();

            //sleep
            try {
                Thread.sleep(10);
            }
            catch (InterruptedException e) {

            }//while
        }
    }// run()


    public void checkIntersections()
    {
        if(player1.rec.intersects(ball.rec))
        {
            ball.reverseDirection();

        }

        if(player2.rec.intersects(ball.rec))
        {
            ball.reverseDirection();

        }


    }


    public void keyPressed( KeyEvent event )
    {
        String keyin;
        keyin = ""+event.getKeyText( event.getKeyCode()); //getKeyCode returns the key code number
        //System.out.println("Key pressed "+keyin);

        //if you press the D make the hero go right by making its right boolean variable true.
        if(keyin.equals("O"))
        {
            player1.up=true;
        }
        if(keyin.equals("L"))
        {
            player1.down=true;
        }
        if(keyin.equals("Q"))
        {
            player2.up=true;
        }
        if(keyin.equals("A"))
        {
            player2.down=true;
        }





    }//keyPressed()


    // This runs whenever a key is released
    public void keyReleased( KeyEvent event )
    {
        String keyin;
        keyin = ""+event.getKeyText( event.getKeyCode());
        //System.out.println ("Key released: "+ keyin);


        //if the D key is "unpressed" make the right motion stop.
        //if the D key is "unpressed" make the right motion stop.
        if(keyin.equals("O"))
        {
            player1.up=false;
        }
        if(keyin.equals("L"))
        {
            player1.down=false;
        }
        if(keyin.equals("Q"))
        {
            player2.up=false;
        }
        if(keyin.equals("A"))
        {
            player2.down=false;
        }


    }//keyReleased() - don't use this one
    public void keyTyped( KeyEvent event )
    {
        //keyTyped() only runs if a printable key is pressed. It does not respond to arrow keys, space, tab, etc.
        char keyin;
        keyin = event.getKeyChar(); //getKeyChar() returns the character of the printable key pressed.
        // System.out.println ("Key Typed: "+ keyin);
    }//keyTyped()



   public void runServer()
   {
      inn = new BufferedReader(new InputStreamReader(System.in));
      st = new sendThread();
      rt = new receiveThread();

   	//All networking stuff has to be put into try - catches
      try //catch(SocketException sx)
      {
         setupNetworking();
         st.start();
         rt.start();
      }//try

      catch(Exception ex2)		// if the above fails close up things and then try again
      {

      }//SocketException sx


   } //runServer

   public void setupNetworking()
   {
      try
      {
         setupConnection();  //setup sockets, wait for a connection
         setupStreams();		//after connected, setup streams
         connected = true;
      }

      catch(Exception ex2)
      {
         System.out.println(ex2);
      } // catch(Exception ex2)

   }

   public void resetConnection()
   {
      try //catch(Exception ex2)
      {
         ois.close();
         server.close();
         connection.close();
         //runServer();
      } //try
      catch(Exception ex2)
      {
         System.out.println(ex2);
      } // catch(Exception ex2)



   }



   class sendThread extends Thread//threads sending to make it less laggy
   {
      public void run()
      {
         while (connected)
         {
            try
            {
            	//System.out.println("fjwehjewhehwehejehjwe");
               textin = inn.readLine();		//read in user input
               //System.out.println("inn.readLine():    "+inn.readLine());//capable of reading in...
               //System.out.println("textIn:    "+textin);//textIn does not accept new value.

               if (textin!=null)
               {
                  if (textin.equals(exitword))  // if "exit" is typed in shutdown the server.
                     serverShutdown();
                  else
                     sendData();					//send data to server
               }
               try
               {
                  Thread.sleep(sleepTime);			// this sets the thread to sleep
               }
               catch (InterruptedException e)
               {
               }
            }//try
            catch (Exception e)
            {
               e.printStackTrace();
            }//catch
         }
      }//run
   }//sendThread

	//receiveThread
   class receiveThread extends Thread//threads sending to make it less laggy
   {
      public void run()
      {
         while (connected)
         {
            try
            {

               getData();

               try
               {
                  Thread.sleep(sleepTime);			// this sets the thread to sleep
               }
               catch (InterruptedException e)
               {
               }
            	//receiving
            }//try
            catch (Exception e)
            {
               e.printStackTrace();
            }//catch
         }
      }//run
   }//receiveThread



	//setup connection
   public void setupConnection() throws IOException
   {
      System.out.println("SERVER MODE ACTIVATED");
      server = new ServerSocket (8000);  						//create the socket at port 8000
      System.out.println("Waiting For Connection...");
      connection = server.accept();							//wait for a connection
      System.out.println("Received connection: "+connection.getInetAddress());
      clientIP=""+connection.getInetAddress();				//print out the client IP address


   }//setupconnection()

	//Setup streams connection
   public void setupStreams() throws IOException
   {
   	//Open up Streams
      System.out.println("Streams Setup");
      oos=new ObjectOutputStream(connection.getOutputStream()); //construct object output stream
      oos.flush();
      ois=new ObjectInputStream(connection.getInputStream());

   }//setupStreams()


	//method to write/send network data
   public void sendData() throws IOException
   {
      try
      {
         nmessage = new networkmessage(myName, textin);
         oos.writeObject(nmessage);
      }//try

      catch (IOException ioException)
      {
         System.out.println("IO exception in sendData");
      }

   }//sendData()



	//method to read in network data
   public void getData() throws IOException
   {
      try
      {
         networkmessage messageIn =(networkmessage)(ois.readObject());
         System.out.println(messageIn.ipnum +" >> "+messageIn.text);

      }//try

      catch (Exception exp1)
      {
         System.out.println("IO exception in getData");
      }

   }//getData()



/*  ****************************************************************
serverShutdown()
set done to true
closes streams
******************************************************************** */

   public void serverShutdown()
   {
      System.out.println("exiting initiated");

      try
      {
         done = true;
         textin = "Chat is terminated.  Have a nice day.";
         sendData();
         oos.close();
         server.close();
         connection.close();
      }

      catch (Exception One)
      {
         System.out.println("bad termination");
      }
   }


}  // class serverProg
