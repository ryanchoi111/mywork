
// KJC @ Milton
// Two way full duplex chat server


import java.net.*;
import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.io.*;
import java.awt.event.*;
import java.awt.geom.*;
import java.awt.image.*;



public class clientProgActual extends Frame
{

   public ObjectOutputStream oos;
   public ObjectInputStream ois;
   public Socket connection;
   public String ip, clientIP, textin, exitword ="exit";
   public networkmessage nmessage;
   public boolean connected=false;
   public boolean done=false;
   public String myName="";
   public int counter = 0;
   public int sleepTime = 3;
   public BufferedReader inn;
   sendThread st;
   receiveThread rt;


/*  main method
	required method for all applications.
	It's the first method run when the program starts.
	This main method calls the serverProg constructor
*/

   public static void main(String[] args)
   {
      new clientProgActual();
   
   
   }


   public   clientProgActual()
   {
   
      try
      {
         BufferedReader brin = new BufferedReader(new InputStreamReader(System.in));         
         System.out.print("Enter Server :>"); //send prompt to DOS window
         ip =brin.readLine();		//read in user input
         System.out.print("Enter your name:>"); //send prompt to DOS window
         
         myName =brin.readLine();		//read in user input
      
      
         
      }
      
      catch (Exception inread)
      {
      }
      runClient();
   
   
   }


/*	runServer()
	This is where all the actual work gets done.
*/

   public void runClient()
   {
      inn = new BufferedReader(new InputStreamReader(System.in));
      st = new sendThread();
      rt = new receiveThread();
   
   	//All networking stuff has to be put into try - catches
      try //catch(
      {
         connection=new Socket(ip, 8000);  //this will wait for a connection
         st.start();
         rt.start();
         setupNetworking();
      }//try
      
      catch(Exception ex2)		// if the above fails close up things and then try again
      {
      
      }//SocketException sx
   
   
   } //runServer
   public void setupConnection() throws IOException
   {  
      System.out.println("SERVER MODE ACTIVATED");
      connection = new Socket (ip,8000);  						//create the socket at port 8000
      System.out.println("Waiting For Connection...");
   
   
   }//setupconnection()

   public void setupNetworking()
   {
      try
      {
         setupConnection();  //setup sockets, wait for a connection
         setupStreams();		//after connected, setup streams
         connected = true;
      }
      
      catch(Exception ex2)
      {
         System.out.println(ex2);
      } // catch(Exception ex2)
   
   }
   	//Setup streams connection
   public void setupStreams() throws IOException
   {
   	//Open up Streams
      System.out.println("Streams Setup");
      oos=new ObjectOutputStream(connection.getOutputStream()); //construct object output stream
      oos.flush();
      ois=new ObjectInputStream(connection.getInputStream());
   
   }//setupStreams()



  /* public void resetConnection()
   {
      try //catch(Exception ex2)
      {
         ois.close();
         client.close();
         connection.close();
         //runServer();
      } //try
      catch(Exception ex2)
      {
         System.out.println(ex2);
      } // catch(Exception ex2)
   }
*/


   class sendThread extends Thread//threads sending to make it less laggy
   {
      public void run()
      {
         while (connected)
         {
            try
            {
            	//System.out.println("fjwehjewhehwehejehjwe");
               textin = inn.readLine();		//read in user input
               //System.out.println("inn.readLine():    "+inn.readLine());//capable of reading in...
               //System.out.println("textIn:    "+textin);//textIn does not accept new value.
            
               try
               {
                  Thread.sleep(sleepTime);			// this sets the thread to sleep
               }
               catch (InterruptedException e)
               {
               }
            }//try
            catch (Exception e)
            {
               e.printStackTrace();
            }//catch
         }
      }//run
   }//sendThread

	//receiveThread
   class receiveThread extends Thread//threads sending to make it less laggy
   {
      public void run()
      {
         while (connected)
         {
            try
            {
            
               getData();
            
               try
               {
                  Thread.sleep(sleepTime);			// this sets the thread to sleep
               }
               catch (InterruptedException e)
               {
               }
            	//receiving
            }//try
            catch (Exception e)
            {
               e.printStackTrace();
            }//catch
         }
      }//run
   }//receiveThread



	
	//method to write/send network data
   public void sendData() throws IOException
   {
      try
      {
         nmessage = new networkmessage(myName, textin);
         oos.writeObject(nmessage);
      }//try
      
      catch (IOException ioException)
      {
         System.out.println("IO exception in sendData");
      }
   
   }//sendData()



	//method to read in network data
   public void getData() throws IOException
   {
      try
      {
         networkmessage messageIn =(networkmessage)(ois.readObject());
         System.out.println(messageIn.ipnum +" >> "+messageIn.text);
      
      }//try
      
      catch (Exception exp1)
      {
         System.out.println("IO exception in sendData");
      }
   
   }//getData()



/*  ****************************************************************
serverShutdown()
set done to true
closes streams
******************************************************************** */

 /*  public void serverShutdown()
   {
      System.out.println("exiting initiated");
   
      try
      {
         done = true;
         textin = "Chat is terminated.  Have a nice day.";
         sendData();
         oos.close();
         server.close();
         connection.close();
      }
      
      catch (Exception One)
      {
         System.out.println("bad termination");
      }
   }*/






}  // class serverProg
