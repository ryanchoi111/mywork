/**
 * Created by yueyang on 2/28/17.
 */
import java.awt.*;


public class Ping {


   public int x = 1280 / 2;

   public int y = 720 / 2;

   public int xVelocity = -4;
    
   public double speed,opposite,adjacent;
   public boolean up, down, left, right,isAlive;
   public double angle,rotation,distance;

   public int yVelocity = 4;
   public int size = 5;
   int HEIGHT = 720;
   int WIDTH = 1280;
   public Rectangle rec;
   int myscore1,myscore2;

   public Ping()
   {
      x = 50;
      y = 100;
      size = 30;
      xVelocity = -4;
      yVelocity = 4;
      isAlive=true;
   
      rec= new Rectangle (x,y,size,size);	//construct a rectangle.  This one uses width and height varibles
   
   } // constructor





   public void move() {
    
   
      x = x + xVelocity;
   
      y = y + yVelocity;
   
      rec = new Rectangle(x, y, size, size);    //construct a rectangle.  This one uses width and height varibles
   
   
      if (x < 0) {
         isAlive=false;
         xVelocity = 4;
         myscore1= myscore1 + 1;
      
      } 
      else if (x> WIDTH - 6) {
         isAlive=false;
      
         myscore2 = myscore2 + 1;
      
      }
   
   
      if (y < 0) {
      
         yVelocity = 4;
      
      } 
      else if (y + size > HEIGHT - 28) {
      
         yVelocity = -4;
      }
   }




   public void reverseDirection() {
      xVelocity = -xVelocity;
   }

   public void reverseDirectionY() {
      yVelocity = -yVelocity;
   }


  /* public void hitWall() {
      if (this.y < 30) {
         reverseDirectionY();
      
      }
   
   }*/


}

