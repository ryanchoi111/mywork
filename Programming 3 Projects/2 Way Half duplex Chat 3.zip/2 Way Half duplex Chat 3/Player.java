// Spirit class
import java.applet.*;
import java.awt.*;
import java.awt.event.*;


// METHOD DEFINITION SECTION

// Constructor Definition
// A constructor builds the object when called and sets variable values.
public class Player
{
    //VARIABLE DECLARATION SECTION
    //Here's where you state which variables you are going to use.
    //use this format public datatype variablename;
    public int xpos;
    public int ypos;
    public int height;
    public int width;
    public int dx, dy;
    public boolean up, down,isAlive;
    public Rectangle rec;
    int playerScore;



    // METHOD DEFINITION SECTION
    // Constructor Method Definition
    // A constructor setups the values for the variables with you create a hero or construct it.
    // This constructor does not allow you to specify any values. It has no parameters.


    // Need to specify the values of your Hero?
    // Add parameters to the constructor to create a second one that lets you pass values into it.
    public Player()
    {
        xpos = 50;
        ypos = 100;
        height = 100;
        width = 50;
        dx=10;
        dy=10;
        playerScore=0;
        rec= new Rectangle (xpos,ypos,width,height);	//construct a rectangle.  This one uses width and height varibles

    } // constructor


    public void move()
    {

        if (up==true)
        {
            moveUp();
        }
        if (down==true)
        {
            moveDown();
        }






    }






    public void moveUp()
    {
        ypos = ypos-dy;

        if (ypos <0)
        {
            ypos = 0;
        }
        rec= new Rectangle (xpos,ypos,width,height);	//create a rectangle at the new x and y position.



    }

    public void moveDown()
    {
        ypos = ypos+dy;

        if (ypos>210)
        {
            ypos = 210;
        }
        rec= new Rectangle (xpos,ypos,width,height);	//create a rectangle at the new x and y position.

    }





}