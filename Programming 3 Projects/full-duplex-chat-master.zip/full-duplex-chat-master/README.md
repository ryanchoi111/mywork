# full-duplex-chat
Full Duplex Chat

## How to use

1. Make sure port 8888 is available
1. Run the App in Server mode
    - java App host
1. Run the App in Client mode
    - java App client
1. You may connect more clients
1. From the Client terminal, enter your chat messages to the server
1. From the Server terminal, enter your chat message to all clients

## Main Components

1. App.java
1. Server.java
1. Client.java
