import java.io.IOException;

public interface UserInput {
    void write(String input) throws IOException;
}
