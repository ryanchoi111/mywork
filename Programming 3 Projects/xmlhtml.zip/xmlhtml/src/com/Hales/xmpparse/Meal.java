package com.Hales.xmpparse;

/**
 * Created by chales on 4/14/2017.
 */
public class Meal {
    String name;
    public Meal(String n)
    {
        name=n;
    }
}
