namespace com.codename1.googlemaps{


public class InternalNativeMapsImpl : IInternalNativeMapsImpl {
    public void initialize() {
    }

    public int getMaxZoom() {
        return 0;
    }

    public long finishPath(long param) {
        return 0;
    }

    public void calcLatLongPosition(int param, int param1) {
    }

    public double getScreenLon() {
        return 0;
    }

    public double getScreenLat() {
        return 0;
    }

    public int getScreenY() {
        return 0;
    }

    public void removeMapElement(long param) {
    }

    public double getLatitude() {
        return 0;
    }

    public int getScreenX() {
        return 0;
    }

    public void setRotateGestureEnabled(bool param) {
    }

    public void removeAllMarkers() {
    }

    public void calcScreenPosition(double param, double param1) {
    }

    public object createNativeMap(int param) {
        return null;
    }

    public double getLongitude() {
        return 0;
    }

    public long beginPath() {
        return 0;
    }

    public void setPosition(double param, double param1) {
    }

    public float getZoom() {
        return 0;
    }

    public void setZoom(double param, double param1, float param2) {
    }

    public void deinitialize() {
    }

    public int getMapType() {
        return 0;
    }

    public int getMinZoom() {
        return 0;
    }

    public void addToPath(long param, double param1, double param2) {
    }

    public void setMapType(int param) {
    }

    public void setShowMyLocation(bool param) {
    }

    public long addMarker(byte[] param, double param1, double param2, string param3, string param4, bool param5) {
        return 0;
    }

    public bool isSupported() {
        return false;
    }

}
}
