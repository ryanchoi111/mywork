#import <Foundation/Foundation.h>

@interface com_codename1_braintree_impl_BraintreeNativeImpl : NSObject {
}

-(void)showChargeUI:(NSString*)param;
-(BOOL)isSupported;
@end
