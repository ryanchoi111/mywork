package com.mycompany.petbnb;

import com.codename1.ui.events.ActionEvent;

public class Screen001 extends com.codename1.ui.Form {
    public Screen001() {
        this(com.codename1.ui.util.Resources.getGlobalResources());
    }
    
    public Screen001(com.codename1.ui.util.Resources resourceObjectInstance) {
        initGuiBuilderComponents(resourceObjectInstance);
    }

    public void onButtonActionEvent(ActionEvent ev) {
    }

    public void onButton_1ActionEvent(ActionEvent ev) {
    }

    //-- DON'T EDIT BELOW THIS LINE!!!
    private void initGuiBuilderComponents(com.codename1.ui.util.Resources resourceObjectInstance) {
    }
//-- DON'T EDIT ABOVE THIS LINE!!!
}
