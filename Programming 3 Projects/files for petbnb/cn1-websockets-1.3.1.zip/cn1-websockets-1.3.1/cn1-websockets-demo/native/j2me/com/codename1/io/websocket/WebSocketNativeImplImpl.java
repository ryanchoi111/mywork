package com.codename1.io.websocket;

public class WebSocketNativeImplImpl {
    public void close() {
    }

    public void send(byte[] param) {
    }

    public void setUrl(String param) {
    }

    public boolean isSupported() {
        return false;
    }

}
