/*
 * Copyright 2010-2015 JetBrains s.r.o.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package kotlin.reflect.jvm.internal.impl.load.java.components

import kotlin.reflect.jvm.internal.impl.descriptors.SourceFile
import kotlin.reflect.jvm.internal.impl.load.java.sources.JavaSourceElement
import kotlin.reflect.jvm.internal.impl.load.java.sources.JavaSourceElementFactory
import kotlin.reflect.jvm.internal.impl.load.java.structure.JavaElement
import kotlin.reflect.jvm.internal.impl.load.java.structure.reflect.ReflectJavaElement

object RuntimeSourceElementFactory : JavaSourceElementFactory {
    class RuntimeSourceElement(override val javaElement: ReflectJavaElement) : JavaSourceElement {
        override fun toString() = javaClass.name + ": " + javaElement.toString()
        override fun getContainingFile(): SourceFile = SourceFile.NO_SOURCE_FILE
    }

    override fun source(javaElement: JavaElement): JavaSourceElement = RuntimeSourceElement(javaElement as ReflectJavaElement)
}
