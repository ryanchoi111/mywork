package com.mycompany.petbnb;


/**
 * Created by chales on 3/30/2017.
 */
public class Peep {
    public String first;
    public String last;

    public Peep( String a,String b)
    {
        first=a;
        last=b;

    }
}
