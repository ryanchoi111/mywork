package com.codename1.braintree.impl;


/**
 *  @deprecated don't use the native interface directly
 */
public interface BraintreeNative extends com.codename1.system.NativeInterface {

	public void showChargeUI(String clientToken);
}
